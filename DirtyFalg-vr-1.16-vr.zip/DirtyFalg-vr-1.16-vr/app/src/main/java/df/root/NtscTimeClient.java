package df.root;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
public final class NtscTimeClient {
    private static final String[] SRC={"https://ntsc.cas.cn/","https://www.ntsc.ac.cn/"};
    private NtscTimeClient(){}
    public static long fetch(){
        for(String s:SRC){long t=tryFetch(s);if(t>0)return t;}
        return 0L;
    }
    private static long tryFetch(String u){
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(u).openConnection();
            c.setRequestMethod("HEAD");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent","DirtyFrag/1.16");
            int rc=c.getResponseCode();
            if(rc<200||rc>=400)return 0L;
            if(!"https".equalsIgnoreCase(c.getURL().getProtocol()))return 0L;
            String d=c.getHeaderField("Date");
            if(d==null)return 0L;
            SimpleDateFormat f=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz",Locale.US);f.setLenient(false);
            f.setTimeZone(TimeZone.getTimeZone("GMT"));
            Date p=f.parse(d);
            if(p==null)return 0L;
            long t=p.getTime();
            return (t>=1577836800000L&&t<=4102444800000L)?t:0L;
        }catch(Exception e){return 0L;}
        finally{if(c!=null)c.disconnect();}
    }
}
