package df.root;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
public final class CardKeyManager {
    public enum R{OK,NOT_FOUND,EXPIRED,BAD_FORMAT}
    public static final class V{
        public final R r; public final long exp;
        V(R x,long e){r=x;exp=e;}
    }
    private static final long DEADLINE=bj(2027,1,1,0,0);
    static final String[][] CARDS_D = {
        {"zWacYGen20261012do3IeHOB", "20261012"},
        {"shtGzReZ20261013cy6RetZd", "20261013"},
        {"Dp7jYbJo20261014Thda7UV3", "20261014"},
    };
    static final String[][] CARDS_W = {
        {"Th20KRBd20261012RfyC1usc", "20261012"},
        {"wGRl1zSD20261013lffFb18i", "20261013"},
        {"E4MKkPLY20261014Gp2B8vgX", "20261014"},
    };
    private CardKeyManager(){}
    public static V verify(android.content.Context ctx,String s,long now){
        if(s==null)return new V(R.NOT_FOUND,0);
        if(now<=0)return new V(R.EXPIRED,0);
        String k=s.trim();
        if(k.isEmpty())return new V(R.NOT_FOUND,0);
        String ymd; int days;
        if((ymd=lookup(CARDS_D,k))!=null)days=1;
        else if((ymd=lookup(CARDS_W,k))!=null)days=7;
        else return new V(R.NOT_FOUND,0);
        if(now>=DEADLINE)return new V(R.EXPIRED,0);
        int y=Integer.parseInt(ymd.substring(0,4));
        int mo=Integer.parseInt(ymd.substring(4,6));
        int d=Integer.parseInt(ymd.substring(6,8));
        long issueMs=bj(y,mo,d,0,0);
        long issueEnd=issueMs+86400000L;
        long act=0; boolean activated=false;
        ExternalCache.Entry ext=ExternalCache.read(ctx);
        if(ext!=null&&ext.cardKey.equals(k)){ act=ext.activateMs; activated=true; }
        else{
            LicenseCache.Entry e=LicenseCache.read();
            if(e!=null&&e.cardKey.equals(k)){ act=e.activateMs; activated=true; }
        }
        if(!activated){
            if(now<issueMs||now>=issueEnd) return new V(R.EXPIRED,0);
            act=now;
            LicenseCache.write(k,act);
            ExternalCache.write(ctx,k,act);
        }
        long expire=act+(long)days*86400000L;
        if(expire>DEADLINE)expire=DEADLINE;
        if(now>=expire)return new V(R.EXPIRED,0);
        return new V(R.OK,expire);
    }
    private static String lookup(String[][] table,String key){
        for(String[] row:table){ if(row[0].equals(key))return row[1]; }
        return null;
    }
    private static long bj(int y,int mo,int d,int h,int mi){
        Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai"));
        c.clear();c.setLenient(false);c.set(y,mo-1,d,h,mi,0);return c.getTimeInMillis();
    }
    public static String fmt(long ms){
        java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy年M月d日 HH:mm",Locale.CHINA);
        f.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        return f.format(new java.util.Date(ms));
    }
}
