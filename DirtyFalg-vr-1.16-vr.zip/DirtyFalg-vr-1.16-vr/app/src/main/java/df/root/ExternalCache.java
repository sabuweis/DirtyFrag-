package df.root;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public final class ExternalCache {
    private static final String SUBDIR = "android_cache";
    private static final String FILENAME = "sys.bin";
    private static final int KEY_LEN = 24;
    private static final int DATA_LEN = KEY_LEN + 8 + 4;
    private static final byte[] XOR = {
        (byte)0x5A, (byte)0xC3, (byte)0x17, (byte)0xE9, (byte)0x4D, (byte)0x82,
        (byte)0x6B, (byte)0xF1, (byte)0x39, (byte)0xA7, (byte)0x2E, (byte)0xD4,
        (byte)0x83, (byte)0x5F, (byte)0xBC, (byte)0x10, (byte)0x77, (byte)0xEE,
        (byte)0x45, (byte)0x92, (byte)0x1C, (byte)0xB8, (byte)0x60, (byte)0x34,
        (byte)0xCD, (byte)0x21, (byte)0x8A, (byte)0xF6, (byte)0x03, (byte)0x9D,
        (byte)0x56, (byte)0xEB, (byte)0x28, (byte)0x74, (byte)0xC0, (byte)0x4F
    };
    private ExternalCache() {}
    public static final class Entry {
        public final String cardKey;
        public final long activateMs;
        public Entry(String k, long m) { cardKey = k; activateMs = m; }
    }
    public static boolean hasPermission(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return true;
        try { return Environment.isExternalStorageManager(); }
        catch (Throwable t) { return false; }
    }
    public static void requestPermission(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return;
        try {
            android.content.Intent i = new android.content.Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            i.setData(Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Throwable t) {
            try {
                android.content.Intent i = new android.content.Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
            } catch (Throwable t2) {}
        }
    }
    public static Entry read(Context ctx) {
        File f = filePath();
        if (f == null || !f.exists() || f.length() != DATA_LEN) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] data = new byte[DATA_LEN];
            if (in.read(data) != DATA_LEN) return null;
            byte[] plain = deobfuscate(data);
            if (plain == null) return null;
            int crc = crc32(plain, 0, KEY_LEN + 8);
            int stored = ((plain[KEY_LEN+8] & 0xFF) << 24) | ((plain[KEY_LEN+9] & 0xFF) << 16) | ((plain[KEY_LEN+10] & 0xFF) << 8) | (plain[KEY_LEN+11] & 0xFF);
            if (crc != stored) return null;
            String key = new String(plain, 0, KEY_LEN, "US-ASCII");
            long ms = 0;
            for (int i = 0; i < 8; i++) ms = (ms << 8) | (plain[KEY_LEN + i] & 0xFFL);
            return new Entry(key, ms);
        } catch (Throwable e) { return null; }
    }
    public static boolean write(Context ctx, String cardKey, long activateMs) {
        if (cardKey == null || cardKey.length() != KEY_LEN) return false;
        File f = filePath();
        if (f == null) return false;
        try {
            byte[] plain = new byte[DATA_LEN];
            System.arraycopy(cardKey.getBytes("US-ASCII"), 0, plain, 0, KEY_LEN);
            for (int i = 0; i < 8; i++) plain[KEY_LEN + i] = (byte)((activateMs >> (56 - 8*i)) & 0xFF);
            int crc = crc32(plain, 0, KEY_LEN + 8);
            plain[KEY_LEN+8]  = (byte)((crc >> 24) & 0xFF);
            plain[KEY_LEN+9]  = (byte)((crc >> 16) & 0xFF);
            plain[KEY_LEN+10] = (byte)((crc >> 8) & 0xFF);
            plain[KEY_LEN+11] = (byte)(crc & 0xFF);
            byte[] data = obfuscate(plain);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
                os.flush();
            }
            return true;
        } catch (Throwable e) { return false; }
    }
    public static void clear(Context ctx) {
        cleanupClones();
        File f = filePath();
        if (f != null && f.exists()) f.delete();
    }
    public static void cleanupClones() {
        File dir = dirPath();
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            String n = f.getName();
            if (n.startsWith("sys") && n.endsWith(".bin") && !n.equals(FILENAME)) {
                try { f.delete(); } catch (Throwable ignored) {}
            }
        }
    }
    private static File dirPath() {
        try {
            File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File dir = new File(dl, SUBDIR);
            if (!dir.exists()) dir.mkdirs();
            return dir;
        } catch (Throwable e) { return null; }
    }
    private static File filePath() {
        File dir = dirPath();
        return dir == null ? null : new File(dir, FILENAME);
    }
    private static byte[] obfuscate(byte[] p) {
        if (p.length != DATA_LEN) return null;
        byte[] r = new byte[DATA_LEN];
        for (int i = 0; i < DATA_LEN; i++) r[i] = p[DATA_LEN - 1 - i];
        for (int i = 0; i < DATA_LEN; i += 2)
            if (i + 1 < DATA_LEN) { byte t = r[i]; r[i] = r[i+1]; r[i+1] = t; }
        for (int i = 0; i < DATA_LEN; i++) r[i] ^= XOR[i % XOR.length];
        return r;
    }
    private static byte[] deobfuscate(byte[] d) {
        if (d.length != DATA_LEN) return null;
        byte[] r = new byte[DATA_LEN];
        for (int i = 0; i < DATA_LEN; i++) r[i] = (byte)(d[i] ^ XOR[i % XOR.length]);
        for (int i = 0; i < DATA_LEN; i += 2)
            if (i + 1 < DATA_LEN) { byte t = r[i]; r[i] = r[i+1]; r[i+1] = t; }
        byte[] out = new byte[DATA_LEN];
        for (int i = 0; i < DATA_LEN; i++) out[i] = r[DATA_LEN - 1 - i];
        return out;
    }
    private static int crc32(byte[] buf, int off, int len) {
        int crc = 0xFFFFFFFF;
        for (int i = 0; i < len; i++) {
            crc ^= (buf[off + i] & 0xFF);
            for (int j = 0; j < 8; j++)
                crc = (crc >>> 1) ^ ((crc & 1) != 0 ? 0xEDB88320 : 0);
        }
        return ~crc;
    }
}
