package df.root;
public final class LicenseGate {
    public enum O{OK,NO_TIME,BAD_CARD,EXPIRED,BAD_FORMAT}
    public static final class V{public final O o;public final long exp;V(O x,long e){o=x;exp=e;}}
    private static volatile boolean granted=false;
    private static volatile long expire=0;
    private static volatile long ntscBaseMs = 0;
    private static volatile long elapsedBaseMs = 0;
    
    private LicenseGate(){}
    
    public static synchronized V verify(android.content.Context ctx,String in){
        long n=NtscTimeClient.fetch();
        if(n<=0)return new V(O.NO_TIME,0);
        CardKeyManager.V v=CardKeyManager.verify(ctx, in, n);
        switch(v.r){
            case OK:return new V(O.OK,v.exp);
            case EXPIRED:return new V(O.EXPIRED,0);
            case BAD_FORMAT:return new V(O.BAD_FORMAT,0);
            default:return new V(O.BAD_CARD,0);
        }
    }
    static synchronized void grant(long expMs, long ntscNow){
        granted=true;
        expire=expMs;
        if(ntscNow>0){
            ntscBaseMs=ntscNow;
            elapsedBaseMs=android.os.SystemClock.elapsedRealtime();
        }
    }
    public static boolean isGranted(){
        if (!granted) return false;
        if (ntscBaseMs <= 0) {
            reset();
            return false;
        }
        long elapsedNow = android.os.SystemClock.elapsedRealtime();
        long estimated = ntscBaseMs + (elapsedNow - elapsedBaseMs);
        if (expire > 0 && estimated >= expire) {
            reset();
            return false;
        }
        return true;
    }
    public static void updateTimeBase(long ntsc, long elapsed){
        ntscBaseMs = ntsc;
        elapsedBaseMs = elapsed;
    }
    public static long expireMs(){return expire;}
    static synchronized void reset(){granted=false;expire=0;}
}
