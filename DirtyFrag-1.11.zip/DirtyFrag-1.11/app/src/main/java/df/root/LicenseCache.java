package df.root;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** 卡密激活缓存，32 字节：24B 卡密 + 8B 激活时间戳 */
public final class LicenseCache {
    private static final String FILE_NAME = "license.dat";
    private static final int KEY_LEN = 24;
    private static Context appCtx;

    private LicenseCache() {}

    public static void init(Context ctx) {
        appCtx = ctx.getApplicationContext();
    }

    public static final class Entry {
        public final String cardKey;
        public final long activateMs;
        public Entry(String k, long m) { cardKey = k; activateMs = m; }
    }

    public static Entry read() {
        if (appCtx == null) return null;
        File f = new File(appCtx.getFilesDir(), FILE_NAME);
        if (!f.exists() || f.length() != KEY_LEN + 8) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[KEY_LEN + 8];
            if (in.read(buf) != buf.length) return null;
            String key = new String(buf, 0, KEY_LEN, "US-ASCII");
            long ms = 0;
            for (int i = 0; i < 8; i++) ms = (ms << 8) | (buf[KEY_LEN + i] & 0xFFL);
            return new Entry(key, ms);
        } catch (Exception e) { return null; }
    }

    public static boolean write(String cardKey, long activateMs) {
        if (appCtx == null) return false;
        if (cardKey == null || cardKey.length() != KEY_LEN) return false;
        try (FileOutputStream out = new FileOutputStream(
                new File(appCtx.getFilesDir(), FILE_NAME))) {
            byte[] buf = new byte[KEY_LEN + 8];
            System.arraycopy(cardKey.getBytes("US-ASCII"), 0, buf, 0, KEY_LEN);
            for (int i = 0; i < 8; i++)
                buf[KEY_LEN + i] = (byte) ((activateMs >> (56 - 8 * i)) & 0xFF);
            out.write(buf);
            out.flush();
            return true;
        } catch (Exception e) { return false; }
    }

    public static void clear() {
        if (appCtx == null) return;
        File f = new File(appCtx.getFilesDir(), FILE_NAME);
        if (f.exists()) f.delete();
    }
}
