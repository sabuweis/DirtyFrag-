package df.root;
public final class LicenseGate {
    public enum O{OK,NO_TIME,BAD_CARD,EXPIRED,BAD_FORMAT}
    public static final class V{public final O o;public final long exp;V(O x,long e){o=x;exp=e;}}
    // 授权状态只在内存，不落盘
    private static volatile boolean granted=false;
    private static volatile long expire=0;
    private LicenseGate(){}
    /**
     * 纯函数式校验：不修改任何状态，只返回结果。
     * 授权由 grant() 单独调用，避免并发写 expire。
     */
    public static synchronized V verify(String in){
        long n=NtscTimeClient.fetch();
        if(n<=0)return new V(O.NO_TIME,0);
        CardKeyManager.V v=CardKeyManager.verify(in,n);
        switch(v.r){
            case OK:return new V(O.OK,v.exp);
            case EXPIRED:return new V(O.EXPIRED,0);
            case BAD_FORMAT:return new V(O.BAD_FORMAT,0);
            default:return new V(O.BAD_CARD,0);
        }
    }
    /** 只有校验通过后才能调用，用于写入内存授权状态 */
    static synchronized void grant(long expMs){
        granted=true;
        expire=expMs;
    }
    public static boolean isGranted(){return granted;}
    public static long expireMs(){return expire;}
    static synchronized void reset(){granted=false;expire=0;}
}
