package df.root;
public final class LicenseGate {
    public enum O{OK,NO_TIME,BAD_CARD,EXPIRED,BAD_FORMAT}
    public static final class V{public final O o;public final long exp;V(O x,long e){o=x;exp=e;}}
    // 授权状态只在内存，不落盘
    private static volatile boolean granted=false;
    private static volatile long expire=0;
    private LicenseGate(){}
    /**
     * 纯函数式校验：不修改任何状态，只返回结果。
     * 授权由 grant() 单独调用，避免并发写 expire。
     */
    public static synchronized V verify(android.content.Context ctx,String in){
        long n=NtscTimeClient.fetch();
        if(n<=0)return new V(O.NO_TIME,0);
        CardKeyManager.V v=CardKeyManager.verify(ctx, in, n);
        switch(v.r){
            case OK:return new V(O.OK,v.exp);
            case EXPIRED:return new V(O.EXPIRED,0);
            case BAD_FORMAT:return new V(O.BAD_FORMAT,0);
            default:return new V(O.BAD_CARD,0);
        }
    }
    /** 只有校验通过后才能调用，用于写入内存授权状态 */
    static synchronized void grant(long expMs, long ntscNow){
        granted=true;
        expire=expMs;
        if(ntscNow>0){
            ntscBaseMs=ntscNow;
            elapsedBaseMs=android.os.SystemClock.elapsedRealtime();
        }
    }
    public static boolean isGranted(){
        if (!granted) return false;
        // 时间基准未初始化 → 视为不可信，拒绝（防"授权后未刷新基准就跳过过期检查"）
        if (ntscBaseMs <= 0) {
            reset();
            return false;
        }
        long elapsedNow = android.os.SystemClock.elapsedRealtime();
        long estimated = ntscBaseMs + (elapsedNow - elapsedBaseMs);
        if (expire > 0 && estimated >= expire) {
            reset();
            return false;
        }
        return true;
    }

    // 时间基准（由 MainActivity 定时刷新）
    private static volatile long ntscBaseMs = 0;
    private static volatile long elapsedBaseMs = 0;
    public static void updateTimeBase(long ntsc, long elapsed){
        ntscBaseMs = ntsc;
        elapsedBaseMs = elapsed;
    }
    public static long expireMs(){return expire;}
    public static long currentNtscBase(){return ntscBaseMs;}
    static synchronized void reset(){granted=false;expire=0;}
}
