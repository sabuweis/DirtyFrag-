package df.root;
import android.animation.*;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.*;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.DialogFragment;
public class LicenseDialogFragment extends DialogFragment {
    public interface CB{void ok();}
    private EditText et;private Button bt;private View bl;
    private CB cb;private boolean busy;
    public void setCB(CB c){cb=c;}
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup g,@Nullable Bundle s){
        return i.inflate(R.layout.dialog_license,g,false);
    }
    @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
        et=v.findViewById(R.id.etCardKey);
        bt=v.findViewById(R.id.btnConfirm);
        bl=v.findViewById(R.id.blurBackground);
        int w=getResources().getDisplayMetrics().widthPixels;
        ViewGroup.LayoutParams lp=bt.getLayoutParams();lp.width=w/3;bt.setLayoutParams(lp);
        lp=et.getLayoutParams();lp.width=(int)(w*0.70f);et.setLayoutParams(lp);
        et.requestFocus();
        et.postDelayed(()->{
            if(!isAdded())return;
            InputMethodManager im=(InputMethodManager)requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if(im!=null)im.showSoftInput(et,0);
        },200);
        bt.setOnClickListener(x->run());
        et.setOnEditorActionListener((tv,a,e)->{run();return true;});

        LicenseCache.Entry entry = LicenseCache.read();
        if (entry != null) {
            new Thread(() -> {
                long t = NtscTimeClient.fetch();
                if (t <= 0) return;
                CardKeyManager.V v = CardKeyManager.verify(entry.cardKey, t);
                if (v.r == CardKeyManager.R.OK) {
                    runOnUi(() -> { if (isAdded() && et != null) et.setText(entry.cardKey); });
                } else if (v.r == CardKeyManager.R.EXPIRED) {
                    LicenseCache.clear();
                }
            }).start();
        }
    }
    @NonNull @Override public Dialog onCreateDialog(@Nullable Bundle s){
        Dialog d=super.onCreateDialog(s);
        if(d.getWindow()!=null)d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return d;
    }
    @Override public void onStart(){
        super.onStart();
        Dialog d=getDialog();if(d==null||d.getWindow()==null)return;
        Window w=d.getWindow();
        w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S){
            w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
            w.setBackgroundBlurRadius(48);
        }
        bl.setBackgroundColor(0x99000000);
    }
    private void run(){
        if(busy||et==null||bt==null)return;
        busy=true;
        bt.setEnabled(false);bt.setText("校验中...");
        final String in=et.getText().toString().trim();
        new Thread(()->{
            final LicenseGate.V v=LicenseGate.verify(in);
            runOnUi(()->{
                if(!isAdded())return;
                if(v.o==LicenseGate.O.OK){
                    Toast.makeText(requireContext(),"校验通过，到期时间："+CardKeyManager.fmt(v.exp),Toast.LENGTH_LONG).show();
                    exit(v.exp);
                }else{
                    String m;
                    switch(v.o){
                        case NO_TIME:m="无法连接国家授时中心，请检查网络";break;
                        case EXPIRED:m="卡密已过期";break;
                        case BAD_FORMAT:m="卡密格式错误";break;
                        default:m="卡密无效";
                    }
                    Toast.makeText(requireContext(),m,Toast.LENGTH_SHORT).show();
                    et.setText("");bt.setEnabled(true);bt.setText("确定");busy=false;
                }
            });
        }).start();
    }
    private void runOnUi(Runnable r){
        if(getActivity()!=null)getActivity().runOnUiThread(r);
    }
    private void exit(final long expMs){
        // 关键：先 grant，动画随后；动画结束只负责 dismiss 和回调
        LicenseGate.grant(expMs);
        ValueAnimator a1=ValueAnimator.ofFloat(1f,0f);a1.setDuration(200);
        a1.setInterpolator(new DecelerateInterpolator());
        a1.addUpdateListener(a->{
            if(!isAdded()||et==null||bt==null)return;
            float v=(float)a.getAnimatedValue();
            et.setAlpha(v);bt.setAlpha(v);
            float sc=0.9f+0.1f*v;et.setScaleX(sc);et.setScaleY(sc);bt.setScaleX(sc);bt.setScaleY(sc);
        });
        a1.start();
        ValueAnimator a2=ValueAnimator.ofFloat(1f,0f);a2.setDuration(500);
        a2.setInterpolator(new DecelerateInterpolator());
        a2.addUpdateListener(a->{
            if(!isAdded()||bl==null)return;
            float v=(float)a.getAnimatedValue();
            bl.setBackgroundColor(((int)(0x99*v))<<24);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S
                    &&getDialog()!=null&&getDialog().getWindow()!=null)
                getDialog().getWindow().setBackgroundBlurRadius((int)(48*v));
        });
        a2.addListener(new AnimatorListenerAdapter(){
            @Override public void onAnimationEnd(Animator a){
                if(!isAdded())return;
                if(cb!=null)cb.ok();
                dismissAllowingStateLoss();
            }
        });
        a2.start();
    }
}
