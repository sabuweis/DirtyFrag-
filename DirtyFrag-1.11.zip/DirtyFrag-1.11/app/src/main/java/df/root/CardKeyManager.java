package df.root;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 卡密校验。
 * 卡密本身只用于识别身份 + 给用户看启用日期，程序不解析卡密里的日期。
 * 有效期完全来自卡密表（第二列 = 发行日期 YYYYMMDD）。
 * 天卡：发行日 + 1 天失效
 * 周卡：发行日 + 7 天失效
 * 全局截止：北京时间 2027-01-01 00:00
 */
public final class CardKeyManager {
    public enum R{OK,NOT_FOUND,EXPIRED,BAD_FORMAT}
    public static final class V{
        public final R r;
        public final long exp;
        V(R x,long e){r=x;exp=e;}
    }
    private static final long DEADLINE=bj(2027,1,1,0,0);

    // ============ 天卡表：{卡密, 发行日期YYYYMMDD} ============
    static final String[][] CARDS_D = {
        {"zWacYGen20261012do3IeHOB", "20261012"},
        {"shtGzReZ20261013cy6RetZd", "20261013"},
        {"Dp7jYbJo20261014Thda7UV3", "20261014"},
        {"JXQVYuU4202610153P1yc1Q4", "20261015"},
        {"cIwnQxIr20261016FR8uku90", "20261016"},
        {"qTehBSiH20261017zFFUqeYu", "20261017"},
        {"jIDhZwo7202610186NLuuwfG", "20261018"},
        {"kiLL2UPx20261019P7Rcp9On", "20261019"},
        {"7OFN4fUW202610203kWUn7b5", "20261020"},
        {"kYLSgePw20261021hd3d7024", "20261021"},
        {"mKV6C8JR20261022i0VGH5iz", "20261022"},
        {"EybFReQR20261023AYtSxUDq", "20261023"},
        {"OqTqLTgw20261024V3EQRn4L", "20261024"},
        {"3yipIrei20261025YNOsY7dq", "20261025"},
        {"Xk83jsUU20261026s3tsySSj", "20261026"},
        {"bmA13qXD202610273Nc1AKrC", "20261027"},
        {"PhaUenVl20261028dLItSIQi", "20261028"},
        {"d8sXKzvM20261029V4t9kjfn", "20261029"},
        {"zULhZCeM20261030CPqBAJKQ", "20261030"},
        {"ThVL4jsD20261031ChtOaLCC", "20261031"},
        {"GMEh7exl20261101bwDti7X8", "20261101"},
        {"6feqVwUz20261102X0GWbWNp", "20261102"},
        {"htl0F9aJ20261103PO7W8IYO", "20261103"},
        {"FUKULndF202611042uYNi496", "20261104"},
        {"aBzkAOQD20261105B81cVQwx", "20261105"},
        {"UspriiIG202611069MoaCGDs", "20261106"},
        {"OxmtNNQC20261107UX4NOpFA", "20261107"},
        {"Msil4HzN20261108wGhinl80", "20261108"},
        {"kEza4KHq20261109gzWGoYzR", "20261109"},
        {"po7zJDi320261110lnJYbDjt", "20261110"},
        {"htPQGpd52026111176vCYftS", "20261111"},
        {"XJSaiMS820261112HKNlvDPS", "20261112"},
        {"T79PXhoX20261113opV8pDpe", "20261113"},
        {"0pyYuMbq20261114m2UNp4TL", "20261114"},
        {"VbR3NvRR20261115GZ1FIMI9", "20261115"},
        {"mqnGyYaO20261116POOBO0sH", "20261116"},
        {"9Za7GJH620261117LoTv1vGr", "20261117"},
        {"H0f5xOGu20261118s6feUrqO", "20261118"},
        {"BJtcoU6U20261119Z4JkN9VZ", "20261119"},
        {"Z6NI1aO820261120KiDk8DQs", "20261120"},
        {"ECwOghyB20261121r7nRgTWe", "20261121"},
        {"tIM5Pkjz20261122Hk9ooTla", "20261122"},
        {"CRiWWvAh20261123Okplvyis", "20261123"},
        {"ZQzWIq4B20261124eGoMfe5f", "20261124"},
        {"x7U6JoXE20261125eW9BqIgg", "20261125"},
        {"jwgwVjSH20261126jNfLNNNp", "20261126"},
        {"AEdG39zL202611272Q4VGUMJ", "20261127"},
        {"m24omfap20261128Wy0i5oYG", "20261128"},
        {"PQf0zFEV202611299qkpE3ZD", "20261129"},
        {"RpdSBFCV202611301sHRGvZI", "20261130"},
        {"sjbgggPX20261201PqyBlSjb", "20261201"},
        {"zkjMBtBe2026120256a8QI1x", "20261202"},
        {"Ec2Rs9cv20261203XGoyjpmx", "20261203"},
        {"14klbupQ20261204yqDLgr1o", "20261204"},
        {"lqzwaWaI20261205B4liq1vL", "20261205"},
        {"ZVb4uyV020261206mjFDlnSK", "20261206"},
        {"cdPPmKYU20261207z7a5Zden", "20261207"},
        {"4fsNyqka20261208p85yCMOS", "20261208"},
        {"50ED8UE520261209qk80681b", "20261209"},
        {"7eepuRGn202612101AJeufCo", "20261210"},
        {"oylIFEJ520261211lWWaECpH", "20261211"},
        {"pocwd8Qt20261212ernT6j2Z", "20261212"},
        {"EdGV4kBj20261213bqYnIdvz", "20261213"},
        {"P97QYSQS20261214TD2HbxPs", "20261214"},
        {"IUxH2BQB20261215nRhB5MNf", "20261215"},
        {"G9bJgnSt20261216AnEI4Tw8", "20261216"},
        {"fhtlFuio20261217lHvyAM4S", "20261217"},
        {"BIGpbnaP20261218Qan4Gkn5", "20261218"},
        {"K1voux1n202612199bHsx8Qh", "20261219"},
        {"8uOXYISd20261220V9WlSE6o", "20261220"},
        {"rDaWm82V20261221RTmb1CU5", "20261221"},
        {"7tdjXqkC20261222gYmyJPFs", "20261222"},
        {"acGTYf9J20261223Y7lemxLJ", "20261223"},
        {"ZycygiDq20261224Uk3vTIDY", "20261224"},
        {"OkOYZ05Z20261225y4L7FV68", "20261225"},
        {"qd8m41zE20261226AVDMsH0y", "20261226"},
        {"0Y9ais7320261227lY9PZ5O0", "20261227"},
        {"8nV7UqFP20261228uD3V0x0i", "20261228"},
        {"T7yhPUKJ20261229JIamC4tc", "20261229"},
        {"H5KPdkdf202612308jxxru7Y", "20261230"},
        {"r1MitrhV20261231fEe4kpSD", "20261231"},
    };

    // ============ 周卡表：{卡密, 发行日期YYYYMMDD} ============
    static final String[][] CARDS_W = {
        {"Th20KRBd20261012RfyC1usc", "20261012"},
        {"wGRl1zSD20261013lffFb18i", "20261013"},
        {"E4MKkPLY20261014Gp2B8vgX", "20261014"},
        {"koDUhyUm20261015fLkeiLvE", "20261015"},
        {"2ZhP8OjA20261016YeLLtuhZ", "20261016"},
        {"YyEJitNt20261017C11DI6XJ", "20261017"},
        {"Zh77LP4n20261018Lr1LSU7f", "20261018"},
        {"8GaB9PkB20261019Is5ngmWb", "20261019"},
        {"RCNofmOy20261020DzaIGcKw", "20261020"},
        {"dj3B5KuH20261021VKiaSHZK", "20261021"},
        {"MvC9yn2H20261022huD5a9Nu", "20261022"},
        {"aicZgiFl20261023T3jayPXL", "20261023"},
        {"En0dyR6520261024xdlr9zHV", "20261024"},
        {"VSI1gR0T20261025G5mGXgVv", "20261025"},
        {"6x4o2gfl20261026kObnKJBk", "20261026"},
        {"sVE4UguM202610274ZdyHsUB", "20261027"},
        {"2HI3U99z20261028FFFF4WK3", "20261028"},
        {"p9BhQcxz20261029Ozg6I1ZB", "20261029"},
        {"xyAeL0jg20261030hjeqdr0G", "20261030"},
        {"hMqXNNkK20261031uRkDWER1", "20261031"},
        {"OEpTiuY3202611016uVNdKwN", "20261101"},
        {"1jN4bBQZ20261102ijVR68AO", "20261102"},
        {"GTeYXT7f20261103844mXCH4", "20261103"},
        {"xvie5UVa20261104oy8GObeM", "20261104"},
        {"gzFJCuDp20261105oKpSMnSg", "20261105"},
        {"mtpWP5jD20261106CRQ47J56", "20261106"},
        {"K5EzUBa320261107OvMsJ09Y", "20261107"},
        {"fAP19rQH202611082ad6GE7i", "20261108"},
        {"uQ4STSXW20261109H0pr0D8I", "20261109"},
        {"5NVZkVJZ202611106ADQwfnq", "20261110"},
        {"xKOxrKrm20261111a3jBWh2h", "20261111"},
        {"PlJULS1u20261112itPORwX1", "20261112"},
        {"tuuyf2Yc20261113KWTmtaWz", "20261113"},
        {"jKRLIVap20261114TC8u6SSF", "20261114"},
        {"qTKWSrtq2026111517WQDtBz", "20261115"},
        {"TScuRBvq20261116UoCAzgyj", "20261116"},
        {"Y7hohQtd202611171vy3C7xv", "20261117"},
        {"lSR6Xsyr20261118SEFcsfYm", "20261118"},
        {"ireXz7r820261119mI7RI228", "20261119"},
        {"sZCLOWjY20261120KUqCP4ba", "20261120"},
        {"ZMmw0drI20261121hxvCrxjF", "20261121"},
        {"gvkERpl320261122VVxdDOBV", "20261122"},
        {"sUsBN6Mr20261123Itd3wzSm", "20261123"},
        {"8lTdiBTO20261124j5rG8kF9", "20261124"},
        {"RSSVYROH202611257fGF4tsJ", "20261125"},
        {"j3qJ7bg620261126MtU7oWUT", "20261126"},
        {"1Rsg8xoG20261127SnylRLfD", "20261127"},
        {"xl5JD7M620261128CifuX0ye", "20261128"},
        {"GKiehLKR20261129hFE8ZlwD", "20261129"},
        {"0WdW7Guy20261130Tw46emL7", "20261130"},
        {"hTcZ3Xbp20261201ODjJSPTt", "20261201"},
        {"2rylLCXk20261202PQb6OhHA", "20261202"},
        {"tIDxeW2Z20261203Rsov2gp9", "20261203"},
        {"Dmn11qeU20261204FZ2RYlt3", "20261204"},
        {"Au5MqZnd20261205HXt572bP", "20261205"},
        {"lmqjatau202612069nFk2SaV", "20261206"},
        {"l0znRESg202612075WEw8SNG", "20261207"},
        {"LoxrmcPi20261208G2vYhNeY", "20261208"},
        {"kH5DdQtQ20261209PmbxMfUf", "20261209"},
        {"BRs7YyXy20261210uhOUz7vi", "20261210"},
        {"K2eUPEu520261211tCK0pzHh", "20261211"},
        {"7nLekoj920261212cqes9lXQ", "20261212"},
        {"NDmGR6tS20261213UMCIkkCu", "20261213"},
        {"uoIx12cQ2026121472uLjfFx", "20261214"},
        {"I9ewUGDi20261215eRimg0Sk", "20261215"},
        {"1KNY5gjQ20261216cwh8OXej", "20261216"},
        {"j4qgLXAC20261217PFw0fSyO", "20261217"},
        {"vEUB0jX920261218UIflOuQZ", "20261218"},
        {"tIHhOB38202612195z22bBOt", "20261219"},
        {"fobtxPn620261220YgZ64rId", "20261220"},
        {"wTuIGqMm20261221hfmqR0Ys", "20261221"},
        {"ADfmffkQ20261222RnCXUcW8", "20261222"},
        {"r1XiNzqw202612233Dzk3Rui", "20261223"},
        {"AbwLjVe220261224hCClD1Oa", "20261224"},
        {"75y53oic20261225rgOje0Bq", "20261225"},
        {"J1gf6rhO202612262PRSmx4d", "20261226"},
        {"fgpOnHtd20261227dNjaHpDU", "20261227"},
        {"JqPA3F2G20261228ooUrlg9S", "20261228"},
        {"BtKG0qM520261229OVrffP7O", "20261229"},
        {"6E0Dd9ch20261230jFJ1p5yP", "20261230"},
        {"P77jKbBb20261231b7X0rZCG", "20261231"},
    };

    private CardKeyManager(){}

    public static V verify(String s,long now){
        if(s==null)return new V(R.NOT_FOUND,0);
        if(now<=0)return new V(R.EXPIRED,0);
        String k=s.trim();
        if(k.isEmpty())return new V(R.NOT_FOUND,0);

        // 卡密里的日期不解析，只查表
        String day=lookup(CARDS_D,k);
        if(day!=null)return check(day,1,now);

        String week=lookup(CARDS_W,k);
        if(week!=null)return check(week,7,now);

        return new V(R.NOT_FOUND,0);
    }

    /** 表里查找卡密，返回发行日期 */
    private static String lookup(String[][] table,String key){
        for(String[] row:table){
            if(row[0].equals(key))return row[1];
        }
        return null;
    }

    /** 用表里日期计算有效期，days=1 天卡，days=7 周卡 */
    private static V check(String ymd,int days,long now){
        int y=Integer.parseInt(ymd.substring(0,4));
        int mo=Integer.parseInt(ymd.substring(4,6));
        int d=Integer.parseInt(ymd.substring(6,8));
        long i=bj(y,mo,d,0,0);
        long e=i+(long)days*86400000L;
        if(e>DEADLINE)e=DEADLINE;
        if(now<i||now>=e)return new V(R.EXPIRED,0);
        return new V(R.OK,e);
    }

    private static long bj(int y,int mo,int d,int h,int mi){
        Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai"));
        c.clear();c.setLenient(false);c.set(y,mo-1,d,h,mi,0);return c.getTimeInMillis();
    }

    public static String fmt(long ms){
        java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy年M月d日 HH:mm",Locale.CHINA);
        f.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        return f.format(new java.util.Date(ms));
    }
}
