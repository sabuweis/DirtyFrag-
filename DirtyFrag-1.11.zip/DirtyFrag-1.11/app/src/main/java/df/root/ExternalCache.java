package df.root;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 外部缓存：Download/android_cache/sys.bin
 * 内容混淆，不写明文卡密。
 * 清 app data 不会删除此文件，防止"清数据重激活"绕过。
 */
public final class ExternalCache {
    private static final String SUBDIR   = "android_cache";
    private static final String FILENAME = "sys.bin";
    private static final int    KEY_LEN  = 24;
    private static final int    DATA_LEN = KEY_LEN + 8 + 4; // 卡密 + 时间戳 + CRC32

    private static final byte[] XOR = {
        (byte)0x5A, (byte)0xC3, (byte)0x17, (byte)0xE9, (byte)0x4D, (byte)0x82,
        (byte)0x6B, (byte)0xF1, (byte)0x39, (byte)0xA7, (byte)0x2E, (byte)0xD4,
        (byte)0x83, (byte)0x5F, (byte)0xBC, (byte)0x10, (byte)0x77, (byte)0xEE,
        (byte)0x45, (byte)0x92, (byte)0x1C, (byte)0xB8, (byte)0x60, (byte)0x34,
        (byte)0xCD, (byte)0x21, (byte)0x8A, (byte)0xF6, (byte)0x03, (byte)0x9D,
        (byte)0x56, (byte)0xEB, (byte)0x28, (byte)0x74, (byte)0xC0, (byte)0x4F
    };

    private ExternalCache() {}

    public static final class Entry {
        public final String cardKey;
        public final long   activateMs;
        public Entry(String k, long m) { cardKey = k; activateMs = m; }
    }

    /** 读外部缓存：优先 Download/android_cache/sys.bin（MediaStore），回退 File API */
    public static Entry read(Context ctx) {
        byte[] data = readViaMediaStore(ctx);
        if (data == null) data = readViaFile();
        if (data == null || data.length != DATA_LEN) return null;
        byte[] plain = deobfuscate(data);
        if (plain == null) return null;
        int crc = crc32(plain, 0, KEY_LEN + 8);
        int stored = ((plain[KEY_LEN+8] & 0xFF) << 24) | ((plain[KEY_LEN+9] & 0xFF) << 16)
                   | ((plain[KEY_LEN+10] & 0xFF) << 8) | (plain[KEY_LEN+11] & 0xFF);
        if (crc != stored) return null;
        try {
            String key = new String(plain, 0, KEY_LEN, "US-ASCII");
            long ms = 0;
            for (int i = 0; i < 8; i++) ms = (ms << 8) | (plain[KEY_LEN + i] & 0xFFL);
            return new Entry(key, ms);
        } catch (Exception e) { return null; }
    }

    /** 写外部缓存：双写 MediaStore + File API，任一成功即算成功 */
    public static boolean write(Context ctx, String cardKey, long activateMs) {
        if (cardKey == null || cardKey.length() != KEY_LEN) return false;
        byte[] plain = new byte[DATA_LEN];
        try { System.arraycopy(cardKey.getBytes("US-ASCII"), 0, plain, 0, KEY_LEN); }
        catch (Exception e) { return false; }
        for (int i = 0; i < 8; i++) plain[KEY_LEN + i] = (byte)((activateMs >> (56 - 8*i)) & 0xFF);
        int crc = crc32(plain, 0, KEY_LEN + 8);
        plain[KEY_LEN+8]  = (byte)((crc >> 24) & 0xFF);
        plain[KEY_LEN+9]  = (byte)((crc >> 16) & 0xFF);
        plain[KEY_LEN+10] = (byte)((crc >> 8) & 0xFF);
        plain[KEY_LEN+11] = (byte)(crc & 0xFF);
        byte[] data = obfuscate(plain);

        boolean ok1 = writeViaMediaStore(ctx, data);
        boolean ok2 = writeViaFile(data);
        return ok1 || ok2;
    }

    public static void clear(Context ctx) {
        // MediaStore 删除
        try {
            ContentResolver cr = ctx.getContentResolver();
            Uri coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String[] proj = {MediaStore.Downloads._ID};
            String sel = MediaStore.Downloads.DISPLAY_NAME + "=? AND "
                       + MediaStore.Downloads.RELATIVE_PATH + " LIKE ?";
            String[] args = {FILENAME, "%" + SUBDIR + "%"};
            Cursor c = cr.query(coll, proj, sel, args, null);
            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    Uri u = ContentUris.withAppendedId(coll, id);
                    cr.delete(u, null, null);
                }
                c.close();
            }
        } catch (Exception ignored) {}
        // File API 删除
        try {
            File f = filePath();
            if (f != null && f.exists()) f.delete();
        } catch (Exception ignored) {}
    }

    // ============ MediaStore 读写 ============

    private static Uri queryMediaStoreUri(Context ctx) {
        try {
            Uri coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            String[] proj = {MediaStore.Downloads._ID};
            String sel = MediaStore.Downloads.DISPLAY_NAME + "=? AND "
                       + MediaStore.Downloads.RELATIVE_PATH + " LIKE ?";
            String[] args = {FILENAME, "%" + SUBDIR + "%"};
            Cursor c = ctx.getContentResolver().query(coll, proj, sel, args, null);
            if (c == null) return null;
            Uri u = null;
            if (c.moveToFirst()) u = ContentUris.withAppendedId(coll, c.getLong(0));
            c.close();
            return u;
        } catch (Exception e) { return null; }
    }

    private static byte[] readViaMediaStore(Context ctx) {
        try {
            Uri u = queryMediaStoreUri(ctx);
            if (u == null) return null;
            try (InputStream in = ctx.getContentResolver().openInputStream(u)) {
                if (in == null) return null;
                byte[] buf = new byte[DATA_LEN];
                int n = 0, r;
                while (n < DATA_LEN && (r = in.read(buf, n, DATA_LEN - n)) > 0) n += r;
                if (n != DATA_LEN) return null;
                return buf;
            }
        } catch (Exception e) { return null; }
    }

    private static boolean writeViaMediaStore(Context ctx, byte[] data) {
        try {
            ContentResolver cr = ctx.getContentResolver();
            Uri exist = queryMediaStoreUri(ctx);
            if (exist != null) cr.delete(exist, null, null);
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, FILENAME);
            cv.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
            cv.put(MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/" + SUBDIR);
            Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return false;
            try (OutputStream os = cr.openOutputStream(u)) {
                if (os == null) return false;
                os.write(data);
                os.flush();
            }
            return true;
        } catch (Exception e) { return false; }
    }

    // ============ File API 读写（Android 9 及以下 / 兜底） ============

    private static File filePath() {
        try {
            File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File dir = new File(dl, SUBDIR);
            if (!dir.exists()) dir.mkdirs();
            return new File(dir, FILENAME);
        } catch (Exception e) { return null; }
    }

    private static byte[] readViaFile() {
        try {
            File f = filePath();
            if (f == null || !f.exists() || f.length() != DATA_LEN) return null;
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[DATA_LEN];
                if (in.read(buf) != DATA_LEN) return null;
                return buf;
            }
        } catch (Exception e) { return null; }
    }

    private static boolean writeViaFile(byte[] data) {
        try {
            File f = filePath();
            if (f == null) return false;
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
                os.flush();
            }
            return true;
        } catch (Exception e) { return false; }
    }

    // ============ 混淆 / 解混淆 ============

    private static byte[] obfuscate(byte[] p) {
        if (p.length != DATA_LEN) return null;
        byte[] r = new byte[DATA_LEN];
        // 1. 反转
        for (int i = 0; i < DATA_LEN; i++) r[i] = p[DATA_LEN - 1 - i];
        // 2. 奇偶块交换
        for (int i = 0; i < DATA_LEN; i += 2) {
            if (i + 1 < DATA_LEN) { byte t = r[i]; r[i] = r[i+1]; r[i+1] = t; }
        }
        // 3. 异或
        for (int i = 0; i < DATA_LEN; i++) r[i] ^= XOR[i % XOR.length];
        return r;
    }

    private static byte[] deobfuscate(byte[] d) {
        if (d.length != DATA_LEN) return null;
        byte[] r = new byte[DATA_LEN];
        // 反向异或
        for (int i = 0; i < DATA_LEN; i++) r[i] = (byte)(d[i] ^ XOR[i % XOR.length]);
        // 反向奇偶交换
        for (int i = 0; i < DATA_LEN; i += 2) {
            if (i + 1 < DATA_LEN) { byte t = r[i]; r[i] = r[i+1]; r[i+1] = t; }
        }
        // 反向反转
        byte[] out = new byte[DATA_LEN];
        for (int i = 0; i < DATA_LEN; i++) out[i] = r[DATA_LEN - 1 - i];
        return out;
    }

    private static int crc32(byte[] buf, int off, int len) {
        int crc = 0xFFFFFFFF;
        for (int i = 0; i < len; i++) {
            crc ^= (buf[off + i] & 0xFF);
            for (int j = 0; j < 8; j++)
                crc = (crc >>> 1) ^ ((crc & 1) != 0 ? 0xEDB88320 : 0);
        }
        return ~crc;
    }
}
